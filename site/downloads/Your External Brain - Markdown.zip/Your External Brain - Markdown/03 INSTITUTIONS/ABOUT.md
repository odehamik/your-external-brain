# What they asked for. What actually happened.

A letter arrives. It may ask for something reasonable; it may ask for something you have already sent twice. Keep the letter and the evidence of what happened together. We can then spend less of the conversation wondering whether the third request has somehow become your first attempt.

Ask what would help this room serve the work. It can hold correspondence, obligations, decisions, evidence, submissions. Make only the shelves wanted; do not import an institution template from Maya’s vault.

An obligation needs a source and the person or body responsible for it. Community decisions remain distinguishable from institutional demands. A funder’s request cannot stand in for community consent.

Keep the state of things plain: drafted, reviewed, submitted with a receipt, accepted with evidence, or held. FINAL in a filename records someone’s optimism. Reopen the actual evidence before reporting submission. Dates without sources stay unverified.

Opening this room authorizes no sending, signing, certification, account connection, payment, or submission. The guide can help prepare what the person asks for; the decision about its next movement remains where it belongs.
